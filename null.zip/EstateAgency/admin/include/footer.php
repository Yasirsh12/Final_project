			<!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            Copyright © 2020 MY EstateAgency. All rights reserved <i class="far fa-registered"> </i>.<br> Dashboard by <a href="#">Mussadiq Farid </a> & <a href="#"> Yasir Shahzad</a>.
                        </div>
                       <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="#"><i class="fab fa-facebook-square" style="color: blue;"> </i> </a>
                                <a href="#"><i class="fab fa-google" style="color: #72e59d;"> </i> </a>
                                <a href="#"><i class="fab fa-instagram" style="color: #ed983c;"> </i> </a>
                                <a href="#"><i class="fab fa-linkedin" style="color: #3c7eec;"> </i> </a>
                                <a href="#"><i class="fab fa-google-plus" style="color: #ed453c;"> </i> </a>
                                <a href="#"><i class="fab fa-twitter" style="color: lightblue;"> </i> </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->