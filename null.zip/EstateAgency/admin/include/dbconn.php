<?php
	$con= mysqli_connect('localhost','root','','estateagency');
	if ($con == false)
	 {
		echo "<h2> Conection Failed!";
	}
	
?>