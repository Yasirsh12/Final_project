	<!-- Optional JavaScript -->
    <script src="../admin/assets/js/jquery-3.3.1.min.js"></script>
    <script src="../admin/assets/js/bootstrap.bundle.js"></script>
    <script src="../admin/assets/js/jquery.slimscroll.js"></script>
    <script src="../admin/assets/js/main-js.js"></script>