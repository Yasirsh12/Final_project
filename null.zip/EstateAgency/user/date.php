<?php
	echo "To day Date is : ". date("d-m-y");
	echo "<br>";
	echo "To day Date is : ". date("l");
	echo "<br>";
	echo "To day Date is : ". date("h-ia");
	echo "<br>";
	
	$date = date('d-m-y h:ia'); 
	echo $date;
?>
