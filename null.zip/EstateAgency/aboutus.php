<?php 
	$Page_title='About Us';
	include_once 'include/head.php';
	
?>

</head>

<body>
	<?php 
		include_once 'include/searchbar.php';
		include_once 'include/header.php';
	?>

  <main id="main">

    <!-- ======= Intro Single ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single"> Properties Of Your Choice </h1>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  About Us
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->

    <!-- ======= About Section ======= -->
    <section class="section-about">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="about-img-box">
              <img src="images/MY.jpg" width="1000" alt="My Image" class="img-fluid">
            </div>
            <div class="sinse-box">
              <h3 class="sinse-title">MY EstateAgency
                <span></span>
                <br> Sinse 2019</h3>
              <p>Sell & Purchase</p>
            </div>
          </div>
        </div>
      </div>
    </section>

	 <!-- ======= Services Section ======= -->
    <section class="section-services section-t8">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap d-flex justify-content-between">
              <div class="title-box">
                <h2 class="title-a">Our Services</h2>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="card-box-c foo">
              <div class="card-header-c d-flex">
                <div class="card-box-ico">
                  <span class="fa fa-gamepad"></span>
                </div>
                <div class="card-title-c align-self-center">
                  <h2 class="title-c">Lifestyle</h2>
                </div>
              </div>
              <div class="card-body-c">
                <p class="content-c">
                  MY EstateAgency provide the best life for the customers. It provides the effective and effcient way to live his life. The Customer won't be worry for things as they have access to things Online.
                </p>
              </div>
              <div class="card-footer-c">
                <a href="#" class="link-c link-icon">Read more
                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-c foo">
              <div class="card-header-c d-flex">
                <div class="card-box-ico">
                  <span class="fa fa-usd"></span>
                </div>
                <div class="card-title-c align-self-center">
                  <h2 class="title-c">Loans</h2>
                </div>
              </div>
              <div class="card-body-c">
                <p class="content-c">
                   MY EstateAgency provide the best way to Customers to get the property with mininium cost and with the good qualities. It provide the support for the customers with the Low Cost and High qualities.
                </p>
              </div>
              <div class="card-footer-c">
                <a href="#" class="link-c link-icon">Read more
                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-c foo">
              <div class="card-header-c d-flex">
                <div class="card-box-ico">
                  <span class="fa fa-home"></span>
                </div>
                <div class="card-title-c align-self-center">
                  <h2 class="title-c">Sell</h2>
                </div>
              </div>
              <div class="card-body-c">
                <p class="content-c">
                  MY EstateAgency provide best qualities to the customers. Our aim is to provide the effective solutions to the customers with maxmium specifications. Provides the 24/7 support for the customer.
                </p>
              </div>
              <div class="card-footer-c">
                <a href="#" class="link-c link-icon">Read more
                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
            </div>
          </div>
        </div>
		<div class="row mt-2">
        	<div class="col-md-4 ftco-animate">
        		<h3 class="heading mb-3 color-b"><i class="fa fa-reply"></i> Quick Replying Process</h3>
                <p>For providing best quality services, we are available 24/7 for your assistance. In case of any query feel free to contact us on 'Mussadiq@gmail.com' or fill the online Question Ask so our service representative can help you.</p>
        	</div>
        	<div class="col-md-4 ftco-animate">
        		<h3 class="heading mb-3 color-b"><i class="fa fa-retweet"></i> 24/7 Customer Support</h3>
                <p>With the increase in the concern for data security and quality , MY Estate Agency makes sure that data security of the devices remains intact along with quality  Selling and Purchasing of Property..</p>
        	</div>
        </div>
    	</div>
      </div>
    </section><!-- End Services Section -->

	
    <!-- =======Team Section ======= -->
    <section class="section-agents section-t8">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap d-flex justify-content-between">
              <div class="title-box">
                <h2 class="title-a">CONTACT US</h2>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
			 <div class="col-md-6">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="images/YASIR.jpg" alt="Agent One" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two"> Yasir Shahzad
                        <br> Owner</a>
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    I'm the Owner of MY Estate Agency, Which provides sell & Purchase of Property Online.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +92 347 0982480</p>
                    <p>
                      <strong>Email: </strong>  Yasir824@gmail.com</p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-dribbble" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="images/mussadiq.jpg" alt="Second Agent" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two">Mussadiq Farid
                        <br> OWNER </a>
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    I'm the OWNER of MY Estate Agency, Which provides sell & Purchase of Property Online.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong>  +92 342 8963951</p>
                    <p>
                      <strong>Email: </strong> Mussadiq@gmail.com</p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="fa fa-dribbble" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section><!-- End About Section-->

  </main><!-- End #main -->

<?php
	include_once "include/footer.php";
?>

</body>

</html>